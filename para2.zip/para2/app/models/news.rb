class News < ActiveRecord::Base
end
