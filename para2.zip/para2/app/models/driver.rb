class Driver < ActiveRecord::Base
end
