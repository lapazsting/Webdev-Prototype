class ParaController < ApplicationController
	def home
	end
	def about
	end
end
